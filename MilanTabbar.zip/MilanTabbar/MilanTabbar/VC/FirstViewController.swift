//
//  FirstViewController.swift
//  TabTc
//
//  Created by mac on 08/10/21.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func GotoNext(_ sender: Any) {
        let homeVC = TempVC.instantiate(fromAppStoryboard: .Main)
        self.navigationController?.pushViewController(homeVC, animated: true)
    }
    
}
